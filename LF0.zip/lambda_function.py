import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    
    client = boto3.client('lex-runtime')
    lex_res = client.post_text(
        botName='DiningReservation',
        botAlias='prod',
        userId='user1',
        inputText=event['messages'][0]['unstructured']['text'],
    )
    print(lex_res)
    return {
        'statusCode': 200,
         'headers': {
            "Access-Control-Allow-Headers" : "*",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
        },
        "messages": [
            {
              "type": "unstructured",
              "unstructured": {
                "id": "string",
                "text": lex_res['message'],
                "timestamp": "string"
              }
            }
        ]
    }
