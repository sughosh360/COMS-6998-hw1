'use strict';
// Close dialog with the customer, reporting fulfillmentState of Failed or Fulfilled ("Thanks, your pizza will arrive in 20 minutes")
function close(sessionAttributes, fulfillmentState, message) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'Close',
            fulfillmentState,
            message,
        },
    };
}
// --------------- Events -----------------------
function dispatch(intentRequest, callback) {
    console.log(`request received for userId=${intentRequest.userId}, intentName=${intentRequest.currentIntent.name}`);
    const sessionAttributes = intentRequest.sessionAttributes;
    const slots = intentRequest.currentIntent.slots;
    const cuisine = slots.Cuisine;
    const location = slots.Location;
    const dining_time = slots.DiningTime;
    const people = slots.NumberOfPeople;
    const phone_number = slots.PhoneNumber;
    // Load the AWS SDK for Node.js
    var AWS = require('aws-sdk');
    // Set the region
    AWS.config.update({region: 'us-east-1'});
    
    // Create an SQS service object
    var AWS = require('aws-sdk');
    // Set the region 
    AWS.config.update({region: 'us-east-1'});
    
    // Create an SQS service object
    var sqs = new AWS.SQS({apiVersion: '2012-11-05'});
    
    var params = {
       // Remove DelaySeconds parameter and value for FIFO queues
      MessageGroupId: phone_number,
      MessageAttributes: {
        "cuisine": {
              DataType: "String",
              StringValue: cuisine
            },
        "location": {
              DataType: "String",
              StringValue: location
            },
        "dining_time":  {
              DataType: "String",
              StringValue: dining_time
            },
        "people": {
              DataType: "String",
              StringValue: people
            },
        "phone_number":{
              DataType: "String",
              StringValue: phone_number
            }
      },
      MessageBody: "Info about restaurants",
      // MessageDeduplicationId: "TheWhistler",  // Required for FIFO queues
      // MessageGroupId: "Group1",  // Required for FIFO queues
      QueueUrl: "https://sqs.us-east-1.amazonaws.com/925351288528/queue.fifo"
    };
    
    sqs.sendMessage(params, function(err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        console.log("Success", data.MessageId);
      }
    });
    callback(close(sessionAttributes, 'Fulfilled',
    {'contentType': 'PlainText', 'content': `You’re all set. Expect my suggestions for ${cuisine} food near ${location} at ${dining_time} for ${people} people. Your contact: ${phone_number} will receive the SMS with suggestions`}));
}
// --------------- Main handler -----------------------
// Route the incoming request based on intent.
// The JSON body of the request is provided in the event slot.
exports.handler = (event, context, callback) => {
    try {
        dispatch(event,
            (response) => {
                callback(null, response);
            });
    } catch (err) {
        callback(err);
    }
};
